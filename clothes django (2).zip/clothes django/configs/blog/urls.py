from idlelib.searchengine import search_reverse

from django.urls import path
from .views import *




urlpatterns = [
    path('', index, name='index'),
    path('category/<int:category_id>', category_page, name='category'),
    path('article/<int:article_id>', article_detail, name='article'),
    path('add_article/', add_article, name='add_article'),
    path('login/', user_login, name='login'),
    path('logout/', user_logout, name='logout'),
    path('register/', register, name='register'),
    path('search/', search_results, name='search'),
    path('article_update/<int:id>', update_articles, name='update'),
    path('delete_article/<int:id>', delete_article, name='delete'),
    path('about/', about_us, name='about'),
]

