from django import template
from blog.models import *
register = template.Library()


@register.simple_tag()
def get_sorters():
    sorters = {
        '-views': 'Views',
        'views': 'Views',
        '-title': 'A - Z',
        'title': 'Z - A',
        '-created_at': 'New products',
        'created_at': 'Old products',
        '-price': 'Expensive products',
        'price': 'Cheap products'
    }
    return sorters